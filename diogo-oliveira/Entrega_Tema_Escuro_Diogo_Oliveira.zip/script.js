
const toggle = document.getElementById('toggle-tema');
const body = document.body;
const descricao = document.getElementById('descricao-tema');

function aplicarTema(escuro) {
    if (escuro) {
        body.classList.add('tema-escuro');
        descricao.textContent = 'Tema Escuro';
    } else {
        body.classList.remove('tema-escuro');
        descricao.textContent = 'Tema Claro';
    }
}

toggle.addEventListener('change', () => {
    const escuro = toggle.checked;
    localStorage.setItem('temaEscuro', escuro);
    aplicarTema(escuro);
});

window.addEventListener('DOMContentLoaded', () => {
    const escuro = JSON.parse(localStorage.getItem('temaEscuro')) || false;
    toggle.checked = escuro;
    aplicarTema(escuro);
});
